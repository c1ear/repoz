<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Storenameaslkd_ModuleFaq2',
    __DIR__
);
?>