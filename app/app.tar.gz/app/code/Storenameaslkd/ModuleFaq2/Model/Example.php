<?php
namespace Storenameaslkd\ModuleFaq2\Model;
use Magento\Framework\Model\AbstractModel;
class Example extends AbstractModel {
    protected function _construct() {
        $this->_init('Storenameaslkd\ModuleFaq2\Model\Resource\Example');
    }
}
?>