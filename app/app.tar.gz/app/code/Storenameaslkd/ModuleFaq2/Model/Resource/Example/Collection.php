<?php
namespace Storenameaslkd\ModuleFaq2\Model\Resource\Example;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
class Collection extends AbstractCollection {
    protected function _construct() {
        $this->_init(
            'Storenameaslkd\ModuleFaq2\Model\Example',
            'Storenameaslkd\ModuleFaq2\Model\Resource\Example'
        );
    }
}
?>