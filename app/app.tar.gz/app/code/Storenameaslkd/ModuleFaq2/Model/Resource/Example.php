<?php
namespace Storenameaslkd\ModuleFaq2\Model\Resource;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
class Example extends AbstractDb {
    protected function _construct() {
        $this->_init('faq_table2', 'id');
    }
}
?>