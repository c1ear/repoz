<?php
namespace Storenameaslkd\ModuleFaq2\Block;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Storenameaslkd\ModuleFaq2\Helper\Data;
use Storenameaslkd\ModuleFaq2\Model\Example;

class Test extends Template {
    public $helper;
    public $model;
    public function __construct(
        Context $context,
        Data $helper,
        Example $model,
        array $data = []
    ){
        $this->helper = $helper;
        $this->model = $model;
        parent::__construct($context, $data);
    }
}
?>