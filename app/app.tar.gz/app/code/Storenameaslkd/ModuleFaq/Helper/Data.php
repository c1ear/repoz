<?php
namespace Storenameaslkd\ModuleFaq\Helper;
use \Magento\Framework\App\Helper\AbstractHelper;
class Data extends AbstractHelper {
    public function getModel($modelName){
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $model = $objectManager->create('\Storenameaslkd\ModuleFaq\Model\\'.ucfirst($modelName));
        return $model;
    }
}
?>