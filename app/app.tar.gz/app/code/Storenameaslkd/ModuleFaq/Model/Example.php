<?php
namespace Storenameaslkd\ModuleFaq\Model;
use Magento\Framework\Model\AbstractModel;
class Example extends AbstractModel {
    protected function _construct() {
        $this->_init('Storenameaslkd\ModuleFaq\Model\Resource\Example');
    }
}
?>