<?php
namespace Storenameaslkd\ModuleFaq\Model\Resource;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
class Example extends AbstractDb {
    protected function _construct() {
        $this->_init('faq_table', 'id');
    }
}
?>