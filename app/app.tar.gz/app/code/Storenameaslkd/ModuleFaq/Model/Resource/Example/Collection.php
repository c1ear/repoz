<?php
namespace Storenameaslkd\ModuleFaq\Model\Resource\Example;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
class Collection extends AbstractCollection {
    protected function _construct() {
        $this->_init(
            'Storenameaslkd\ModuleFaq\Model\Example',
            'Storenameaslkd\ModuleFaq\Model\Resource\Example'
        );
    }
}
?>