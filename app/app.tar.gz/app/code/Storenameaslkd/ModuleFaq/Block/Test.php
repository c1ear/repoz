<?php
namespace Storenameaslkd\ModuleFaq\Block;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Storenameaslkd\ModuleFaq\Helper\Data;
use Storenameaslkd\ModuleFaq\Model\Example;

class Test extends Template {
    public $helper;
    public $model;
    public function __construct(
        Context $context,
        Data $helper,
        Example $model,
        array $data = []
    ){
        $this->helper = $helper;
        $this->model = $model;
        parent::__construct($context, $data);
    }
}
?>