var config = {
    map: {
        '*': {
            "slick": "//cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.js",
        }
    }
};